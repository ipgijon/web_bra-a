# BRAÑA — Guía de imágenes
## Qué descargar, de dónde y dónde colocarlo

Todas las imágenes deben ir en `/var/www/braña/img/`
Ejecuta los comandos desde el servidor Ubuntu.

---

## 1. HERO PRINCIPAL
**Archivo:** `img/hero.jpg`
**Descripción:** Panorámica de los Picos de Europa / Naranjo de Bulnes

Opción A — Unsplash (libre uso comercial):
```bash
wget -O /var/www/braña/img/hero.jpg \
  "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=1800&q=88&fit=crop"
```
Opción B — Busca en Google Imágenes: "Picos de Europa panorámica"
Fuentes de calidad: Wikimedia Commons (licencia libre), Turismo de Asturias (pide permiso)

---

## 2. INTRO — Valle asturiano
**Archivo:** `img/intro-valle.jpg`

```bash
wget -O /var/www/braña/img/intro-valle.jpg \
  "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=1000&q=85&fit=crop"
```

---

## 3. ZONAS — 5 imágenes

### zona-cangas.jpg — Cangas de Onís / Covadonga / Lagos
```bash
wget -O /var/www/braña/img/zona-cangas.jpg \
  "https://images.unsplash.com/photo-1587482936494-81cde49be54b?w=900&q=85&fit=crop"
```
Alternativa ideal: foto real de los Lagos de Covadonga
Fuente: https://www.flickr.com/search/?text=lagos+covadonga&license=2 (Creative Commons comercial)

### zona-cabrales.jpg — Cabrales / Naranjo de Bulnes
```bash
wget -O /var/www/braña/img/zona-cabrales.jpg \
  "https://images.unsplash.com/photo-1533240332313-0db49b459ad6?w=600&q=85&fit=crop"
```
Alternativa ideal: foto del Naranjo de Bulnes (Picu Urriellu)
Buscar en Wikimedia: https://commons.wikimedia.org/wiki/Naranjo_de_Bulnes

### zona-benia.jpg — Benia de Onís / Parres / valle verde
```bash
wget -O /var/www/braña/img/zona-benia.jpg \
  "https://images.unsplash.com/photo-1482784160316-6eb046863ece?w=600&q=85&fit=crop"
```

### zona-llanes.jpg — Llanes / Ribadesella / costa asturiana
```bash
wget -O /var/www/braña/img/zona-llanes.jpg \
  "https://images.unsplash.com/photo-1499346030926-9a72daac6c63?w=600&q=85&fit=crop"
```
Alternativa ideal: foto real de la costa de Llanes (acantilados, playas Torimbia, Ballota)
Fuente: Turismo Asturias https://www.turismoasturias.es (solicitar uso)

### zona-barreiros.jpg — Barreiros / Costa Lugo / Galicia
```bash
wget -O /var/www/braña/img/zona-barreiros.jpg \
  "https://images.unsplash.com/photo-1505118380757-91f5f5632de0?w=600&q=85&fit=crop"
```
Alternativa ideal: foto real de la playa de Barreiros o Reinante (Lugo)

---

## 4. ALOJAMIENTO — 3 imágenes del producto REAL

### ⭐ IMPORTANTE: Estas imágenes deben ser del producto exacto

**aloj-oslo-ext.jpg** — Exterior de la casa móvil Oslo
**aloj-oslo-int.jpg** — Interior de la casa móvil Oslo (salón)
**aloj-piscina.jpg**  — Piscina ILÚ PRO 230

**Contacta con Casa Nova Móvil** para que te faciliten las imágenes de sus productos en alta resolución:
- Web: https://casanovamobile.es
- Tel: +34 617 062 362
- Email: contacto@casanovamobile.es

Alternativamente, puedes hacer capturas de pantalla de alta calidad de sus páginas:
- Casa Oslo: https://casanovamobile.es/product/casa-movil-oslo-2-dormitorios-125-x-42-m/
- Piscina: https://casanovamobile.es/product/piscina-contenedor-ilu-pro-230/

Y colocarlas en:
```
/var/www/braña/img/aloj-oslo-ext.jpg
/var/www/braña/img/aloj-oslo-int.jpg
/var/www/braña/img/aloj-piscina.jpg
```

**Imágenes temporales mientras consigues las reales:**
```bash
# Casa móvil moderna exterior (placeholder)
wget -O /var/www/braña/img/aloj-oslo-ext.jpg \
  "https://images.unsplash.com/photo-1449158743715-0a90ebb6d2d8?w=900&q=85&fit=crop"

# Interior moderno (placeholder)
wget -O /var/www/braña/img/aloj-oslo-int.jpg \
  "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=900&q=85&fit=crop"

# Piscina exterior moderna (placeholder)
wget -O /var/www/braña/img/aloj-piscina.jpg \
  "https://images.unsplash.com/photo-1575429198097-0414ec08e8cd?w=900&q=85&fit=crop"
```

---

## 5. EXPERIENCIAS — 8 imágenes del entorno real

### exp-sella.jpg — Descenso del Sella (río, canoas, verde asturiano)
Fuente ideal: Google "descenso del sella canoa"
Web oficial: https://www.descensodelsella.com
```bash
# Placeholder río verde montaña
wget -O /var/www/braña/img/exp-sella.jpg \
  "https://images.unsplash.com/photo-1468413253725-0d5181091126?w=900&q=85&fit=crop"
```

### exp-cares.jpg — Ruta del Cares (sendero en el desfiladero)
Fuente ideal: Wikimedia Commons, buscar "Garganta del Cares"
```bash
wget -O /var/www/braña/img/exp-cares.jpg \
  "https://images.unsplash.com/photo-1551632436-cbf8dd35adfa?w=600&q=85&fit=crop"
```

### exp-escalada.jpg — Naranjo de Bulnes / escalada Picos de Europa
Fuente ideal: Wikimedia "Naranjo de Bulnes" — hay fotos espectaculares en CC
https://commons.wikimedia.org/wiki/File:Naranjo_de_Bulnes.jpg
```bash
# Placeholder escalada genérica (cambiar por Naranjo real)
wget -O /var/www/braña/img/exp-escalada.jpg \
  "https://images.unsplash.com/photo-1522163182402-834f871fd851?w=600&q=85&fit=crop"
```

### exp-covadonga.jpg — Lagos de Covadonga (Enol / Ercina)
Fuente ideal: Wikimedia "Lagos de Covadonga" — imágenes espectaculares en CC
```bash
wget -O /var/www/braña/img/exp-covadonga.jpg \
  "https://images.unsplash.com/photo-1490730141103-6cac27aaab94?w=600&q=85&fit=crop"
```

### exp-surf.jpg — Surf en Asturias (NO playa caribeña — playa asturiana verde)
Fuente ideal: Escuelas de surf de Llanes o Ribadesella (pedir imágenes a cambio de enlace)
```bash
wget -O /var/www/braña/img/exp-surf.jpg \
  "https://images.unsplash.com/photo-1502680390469-be75c86b636f?w=900&q=85&fit=crop"
```
⚠️  Verificar que la imagen sea de costa atlántica/verde, NO tropical

### exp-caballos.jpg — Rutas a caballo en praderas asturianas
```bash
wget -O /var/www/braña/img/exp-caballos.jpg \
  "https://images.unsplash.com/photo-1553284965-83fd3e82fa5a?w=600&q=85&fit=crop"
```

### exp-sidra.jpg — Sidrería asturiana / escanciado / gastronomía
Fuente ideal: contactar con Sidrería local para fotos auténticas
```bash
wget -O /var/www/braña/img/exp-sidra.jpg \
  "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=600&q=85&fit=crop"
```

### exp-barco.jpg — Barco de pesca / marisco en Barreiros (NO playa tropical)
Fuente ideal: foto real de la cofradía o puerto de Barreiros
```bash
wget -O /var/www/braña/img/exp-barco.jpg \
  "https://images.unsplash.com/photo-1519683109079-d5f539e1542f?w=600&q=85&fit=crop"
```

---

## 6. SOCIOS y CTA
```bash
# Imagen socios (colaboración, zona rural)
wget -O /var/www/braña/img/socios.jpg \
  "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?w=800&q=85&fit=crop"

# CTA amanecer Picos
wget -O /var/www/braña/img/cta-amanecer.jpg \
  "https://images.unsplash.com/photo-1454496522488-7a8e488e8606?w=1800&q=85&fit=crop"
```

---

## SCRIPT: descargar todos los placeholders de una vez

```bash
cd /var/www/braña/img

# Hero y generales
wget -q -O hero.jpg          "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=1800&q=88&fit=crop"
wget -q -O intro-valle.jpg   "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=1000&q=85&fit=crop"

# Zonas
wget -q -O zona-cangas.jpg   "https://images.unsplash.com/photo-1587482936494-81cde49be54b?w=900&q=85&fit=crop"
wget -q -O zona-cabrales.jpg "https://images.unsplash.com/photo-1533240332313-0db49b459ad6?w=600&q=85&fit=crop"
wget -q -O zona-benia.jpg    "https://images.unsplash.com/photo-1482784160316-6eb046863ece?w=600&q=85&fit=crop"
wget -q -O zona-llanes.jpg   "https://images.unsplash.com/photo-1499346030926-9a72daac6c63?w=600&q=85&fit=crop"
wget -q -O zona-barreiros.jpg "https://images.unsplash.com/photo-1505118380757-91f5f5632de0?w=600&q=85&fit=crop"

# Alojamiento (placeholders — reemplazar con fotos reales de casanovamobile.es)
wget -q -O aloj-oslo-ext.jpg "https://images.unsplash.com/photo-1449158743715-0a90ebb6d2d8?w=900&q=85&fit=crop"
wget -q -O aloj-oslo-int.jpg "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=900&q=85&fit=crop"
wget -q -O aloj-piscina.jpg  "https://images.unsplash.com/photo-1575429198097-0414ec08e8cd?w=900&q=85&fit=crop"

# Experiencias
wget -q -O exp-sella.jpg     "https://images.unsplash.com/photo-1468413253725-0d5181091126?w=900&q=85&fit=crop"
wget -q -O exp-cares.jpg     "https://images.unsplash.com/photo-1551632436-cbf8dd35adfa?w=600&q=85&fit=crop"
wget -q -O exp-escalada.jpg  "https://images.unsplash.com/photo-1522163182402-834f871fd851?w=600&q=85&fit=crop"
wget -q -O exp-covadonga.jpg "https://images.unsplash.com/photo-1490730141103-6cac27aaab94?w=600&q=85&fit=crop"
wget -q -O exp-surf.jpg      "https://images.unsplash.com/photo-1502680390469-be75c86b636f?w=900&q=85&fit=crop"
wget -q -O exp-caballos.jpg  "https://images.unsplash.com/photo-1553284965-83fd3e82fa5a?w=600&q=85&fit=crop"
wget -q -O exp-sidra.jpg     "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=600&q=85&fit=crop"
wget -q -O exp-barco.jpg     "https://images.unsplash.com/photo-1519683109079-d5f539e1542f?w=600&q=85&fit=crop"

# Socios y CTA
wget -q -O socios.jpg        "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?w=800&q=85&fit=crop"
wget -q -O cta-amanecer.jpg  "https://images.unsplash.com/photo-1454496522488-7a8e488e8606?w=1800&q=85&fit=crop"

echo "✓ Todas las imágenes descargadas"
```

---

## Conversión a WebP (opcional, mejora velocidad)
```bash
sudo apt install webp -y
for f in /var/www/braña/img/*.jpg; do
  cwebp -q 85 "$f" -o "${f%.jpg}.webp"
done
```
Si conviertes a WebP actualiza las extensiones en index.html.

---

## Imágenes que DEBES sustituir cuanto antes por fotos reales

| Placeholder | Por qué sustituir | Fuente recomendada |
|---|---|---|
| aloj-oslo-ext.jpg | Debe ser la Oslo real | casanovamobile.es |
| aloj-oslo-int.jpg | Debe ser la Oslo real | casanovamobile.es |
| aloj-piscina.jpg  | Debe ser la ILÚ PRO 230 real | casanovamobile.es |
| exp-escalada.jpg  | Debe ser el Naranjo de Bulnes | Wikimedia Commons |
| exp-sella.jpg     | Debe ser el río Sella verde | descensodelsella.com |
| exp-covadonga.jpg | Debe ser los Lagos reales | Wikimedia Commons |

---

*Braña Alojamientos de Naturaleza · braña.com*
