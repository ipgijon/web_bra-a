#!/usr/bin/env python3
"""
BRAÑA — API de formularios de contacto
FastAPI + SMTP Dinaserver
"""

import smtplib
import logging
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime
from typing import Optional
from enum import Enum

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, EmailStr, field_validator
import uvicorn

# ── CONFIGURACIÓN ──────────────────────────────────────────
SMTP_HOST     = "xn--braa-iqa-com.correoseguro.dinaserver.com"
SMTP_PORT     = 465          # SMTPS
SMTP_USER     = "info@xn--braa-iqa.com"
SMTP_PASSWORD = "TU_PASSWORD_AQUI"   # ← cambia esto
EMAIL_TO      = "info@xn--braa-iqa.com"
EMAIL_FROM    = "info@xn--braa-iqa.com"

# Rate limiting simple (en memoria)
RATE_LIMIT_WINDOW = 60   # segundos
RATE_LIMIT_MAX    = 5    # máximo envíos por IP por ventana

# ── LOGGING ────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
    handlers=[
        logging.FileHandler("/var/log/braña-api.log"),
        logging.StreamHandler()
    ]
)
log = logging.getLogger("braña-api")

# ── APP ────────────────────────────────────────────────────
app = FastAPI(title="Braña API", docs_url=None, redoc_url=None)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://xn--braa-iqa.com", "https://braña.com",
                   "http://localhost", "http://127.0.0.1"],
    allow_methods=["POST", "OPTIONS"],
    allow_headers=["Content-Type"],
)

# ── RATE LIMITER ───────────────────────────────────────────
from collections import defaultdict
import time
_rate_store: dict = defaultdict(list)

def check_rate_limit(ip: str) -> bool:
    now = time.time()
    window_start = now - RATE_LIMIT_WINDOW
    _rate_store[ip] = [t for t in _rate_store[ip] if t > window_start]
    if len(_rate_store[ip]) >= RATE_LIMIT_MAX:
        return False
    _rate_store[ip].append(now)
    return True

# ── MODELOS ────────────────────────────────────────────────
class TipoConsulta(str, Enum):
    alojamiento = "alojamiento"
    socio       = "socio"
    inversion   = "inversión"
    otro        = "otro"

class TipoSocio(str, Enum):
    gastronomia = "gastronomía"
    aventura    = "aventura y montaña"
    nautica     = "náutica y costa"
    transfer    = "transfer y logística"
    otro        = "otro"

class ContactoForm(BaseModel):
    nombre:  str
    email:   EmailStr
    telefono: Optional[str] = None
    tipo:    TipoConsulta
    fechas:  Optional[str] = None
    mensaje: str

    @field_validator("nombre")
    @classmethod
    def nombre_valido(cls, v):
        v = v.strip()
        if len(v) < 2 or len(v) > 100:
            raise ValueError("Nombre entre 2 y 100 caracteres")
        return v

    @field_validator("mensaje")
    @classmethod
    def mensaje_valido(cls, v):
        v = v.strip()
        if len(v) < 10 or len(v) > 2000:
            raise ValueError("Mensaje entre 10 y 2000 caracteres")
        return v

    @field_validator("telefono")
    @classmethod
    def telefono_valido(cls, v):
        if v:
            v = v.strip()
            if len(v) > 20:
                raise ValueError("Teléfono demasiado largo")
        return v

class SocioForm(BaseModel):
    nombre_empresa: str
    nombre_contacto: str
    email:   EmailStr
    telefono: Optional[str] = None
    tipo_socio: TipoSocio
    zona:    str
    descripcion: str
    web:     Optional[str] = None

    @field_validator("nombre_empresa", "nombre_contacto", "zona")
    @classmethod
    def campos_validos(cls, v):
        v = v.strip()
        if len(v) < 2 or len(v) > 150:
            raise ValueError("Campo entre 2 y 150 caracteres")
        return v

    @field_validator("descripcion")
    @classmethod
    def descripcion_valida(cls, v):
        v = v.strip()
        if len(v) < 20 or len(v) > 2000:
            raise ValueError("Descripción entre 20 y 2000 caracteres")
        return v

# ── ENVÍO SMTP ─────────────────────────────────────────────
def send_email(subject: str, body_html: str, body_text: str, reply_to: str):
    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"]    = f"Braña Web <{EMAIL_FROM}>"
    msg["To"]      = EMAIL_TO
    msg["Reply-To"] = reply_to

    msg.attach(MIMEText(body_text, "plain", "utf-8"))
    msg.attach(MIMEText(body_html, "html",  "utf-8"))

    with smtplib.SMTP_SSL(SMTP_HOST, SMTP_PORT, timeout=10) as server:
        server.login(SMTP_USER, SMTP_PASSWORD)
        server.sendmail(EMAIL_FROM, EMAIL_TO, msg.as_string())
        log.info(f"Email enviado → {EMAIL_TO} | Asunto: {subject}")

def send_autorespuesta(to_email: str, to_nombre: str, tipo: str):
    """Email de confirmación automática al usuario"""
    subject = "Braña — Hemos recibido tu mensaje"
    body_text = f"""Hola {to_nombre},

Gracias por contactar con Braña.

Hemos recibido tu consulta sobre {tipo} y te responderemos en un plazo máximo de 48 horas.

Un saludo,
El equipo de Braña
https://braña.com
"""
    body_html = f"""<!DOCTYPE html>
<html><head><meta charset="UTF-8"></head>
<body style="font-family:Georgia,serif;background:#0c1607;color:#f0e8d5;margin:0;padding:0">
<div style="max-width:560px;margin:0 auto;padding:3rem 2rem">
  <p style="font-size:1.4rem;letter-spacing:.2em;color:#f0e8d5;margin-bottom:2rem">BRAÑA</p>
  <p style="color:#e0a040;font-size:.8rem;letter-spacing:.2em;text-transform:uppercase;margin-bottom:1rem">Mensaje recibido</p>
  <p style="font-size:1rem;line-height:1.8;color:#f0e8d5">Hola <strong>{to_nombre}</strong>,</p>
  <p style="font-size:.9rem;line-height:1.8;color:rgba(240,232,213,.75);margin-top:.8rem">
    Gracias por contactar con Braña. Hemos recibido tu consulta sobre <strong>{tipo}</strong>
    y te responderemos en un plazo máximo de 48 horas.
  </p>
  <div style="margin:2rem 0;padding:1.5rem;border:.5px solid rgba(196,132,42,.3)">
    <p style="font-size:.8rem;color:rgba(240,232,213,.5);margin:0">
      Si tienes cualquier urgencia puedes escribirnos directamente a
      <a href="mailto:info@braña.com" style="color:#e0a040">info@braña.com</a>
    </p>
  </div>
  <p style="font-size:.8rem;color:rgba(240,232,213,.4);margin-top:2rem">
    El equipo de Braña · <a href="https://braña.com" style="color:#c4842a">braña.com</a>
  </p>
</div>
</body></html>"""
    try:
        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"]    = f"Braña <{EMAIL_FROM}>"
        msg["To"]      = to_email
        msg.attach(MIMEText(body_text, "plain", "utf-8"))
        msg.attach(MIMEText(body_html, "html",  "utf-8"))
        with smtplib.SMTP_SSL(SMTP_HOST, SMTP_PORT, timeout=10) as server:
            server.login(SMTP_USER, SMTP_PASSWORD)
            server.sendmail(EMAIL_FROM, to_email, msg.as_string())
    except Exception as e:
        log.warning(f"Autorespuesta fallida a {to_email}: {e}")

# ── ENDPOINTS ──────────────────────────────────────────────
@app.get("/health")
def health():
    return {"status": "ok", "service": "braña-api"}

@app.post("/api/contacto")
async def contacto(form: ContactoForm, request: Request):
    ip = request.client.host
    if not check_rate_limit(ip):
        raise HTTPException(429, "Demasiados intentos. Espera un momento.")

    now = datetime.now().strftime("%d/%m/%Y %H:%M")

    body_text = f"""NUEVO CONTACTO — BRAÑA
{'='*40}
Fecha:    {now}
Nombre:   {form.nombre}
Email:    {form.email}
Teléfono: {form.telefono or '—'}
Consulta: {form.tipo.value}
Fechas:   {form.fechas or '—'}

MENSAJE:
{form.mensaje}
{'='*40}
IP: {ip}
"""

    body_html = f"""<!DOCTYPE html>
<html><head><meta charset="UTF-8"></head>
<body style="font-family:Arial,sans-serif;background:#f4f4f4;padding:2rem">
<div style="max-width:600px;margin:0 auto;background:#fff;border-radius:8px;overflow:hidden">
  <div style="background:#1b3a0e;padding:1.5rem 2rem">
    <p style="color:#f0e8d5;font-family:Georgia,serif;font-size:1.3rem;letter-spacing:.2em;margin:0">BRAÑA</p>
    <p style="color:#e0a040;font-size:.75rem;letter-spacing:.2em;margin:.3rem 0 0;text-transform:uppercase">Nuevo mensaje de contacto</p>
  </div>
  <div style="padding:2rem">
    <table style="width:100%;border-collapse:collapse;font-size:.9rem">
      <tr><td style="padding:.5rem 0;color:#888;width:100px">Fecha</td><td style="padding:.5rem 0;font-weight:bold">{now}</td></tr>
      <tr><td style="padding:.5rem 0;color:#888">Nombre</td><td style="padding:.5rem 0;font-weight:bold">{form.nombre}</td></tr>
      <tr><td style="padding:.5rem 0;color:#888">Email</td><td style="padding:.5rem 0"><a href="mailto:{form.email}" style="color:#c4842a">{form.email}</a></td></tr>
      <tr><td style="padding:.5rem 0;color:#888">Teléfono</td><td style="padding:.5rem 0">{form.telefono or '—'}</td></tr>
      <tr><td style="padding:.5rem 0;color:#888">Consulta</td><td style="padding:.5rem 0"><span style="background:#e8f4e8;color:#1b3a0e;padding:.2rem .6rem;border-radius:4px;font-size:.8rem">{form.tipo.value}</span></td></tr>
      <tr><td style="padding:.5rem 0;color:#888">Fechas</td><td style="padding:.5rem 0">{form.fechas or '—'}</td></tr>
    </table>
    <div style="margin-top:1.5rem;padding:1rem;background:#f9f9f9;border-left:3px solid #c4842a;border-radius:0 4px 4px 0">
      <p style="color:#888;font-size:.8rem;margin:0 0 .5rem">Mensaje:</p>
      <p style="margin:0;line-height:1.7;color:#333">{form.mensaje.replace(chr(10), '<br>')}</p>
    </div>
    <p style="margin-top:1.5rem;font-size:.75rem;color:#aaa">IP: {ip}</p>
  </div>
</div>
</body></html>"""

    try:
        send_email(
            subject=f"[Braña] Contacto — {form.tipo.value} — {form.nombre}",
            body_html=body_html,
            body_text=body_text,
            reply_to=form.email
        )
        send_autorespuesta(form.email, form.nombre, form.tipo.value)
        return {"ok": True, "message": "Mensaje enviado correctamente"}
    except Exception as e:
        log.error(f"Error enviando contacto: {e}")
        raise HTTPException(500, "Error al enviar el mensaje. Inténtalo de nuevo.")


@app.post("/api/socios")
async def socios(form: SocioForm, request: Request):
    ip = request.client.host
    if not check_rate_limit(ip):
        raise HTTPException(429, "Demasiados intentos. Espera un momento.")

    now = datetime.now().strftime("%d/%m/%Y %H:%M")

    body_text = f"""NUEVA SOLICITUD DE SOCIO — BRAÑA
{'='*40}
Fecha:          {now}
Empresa:        {form.nombre_empresa}
Contacto:       {form.nombre_contacto}
Email:          {form.email}
Teléfono:       {form.telefono or '—'}
Tipo socio:     {form.tipo_socio.value}
Zona:           {form.zona}
Web:            {form.web or '—'}

DESCRIPCIÓN:
{form.descripcion}
{'='*40}
IP: {ip}
"""

    body_html = f"""<!DOCTYPE html>
<html><head><meta charset="UTF-8"></head>
<body style="font-family:Arial,sans-serif;background:#f4f4f4;padding:2rem">
<div style="max-width:600px;margin:0 auto;background:#fff;border-radius:8px;overflow:hidden">
  <div style="background:#1b3a0e;padding:1.5rem 2rem">
    <p style="color:#f0e8d5;font-family:Georgia,serif;font-size:1.3rem;letter-spacing:.2em;margin:0">BRAÑA</p>
    <p style="color:#e0a040;font-size:.75rem;letter-spacing:.2em;margin:.3rem 0 0;text-transform:uppercase">Nueva solicitud de socio</p>
  </div>
  <div style="padding:2rem">
    <table style="width:100%;border-collapse:collapse;font-size:.9rem">
      <tr><td style="padding:.5rem 0;color:#888;width:130px">Fecha</td><td style="padding:.5rem 0;font-weight:bold">{now}</td></tr>
      <tr><td style="padding:.5rem 0;color:#888">Empresa</td><td style="padding:.5rem 0;font-weight:bold">{form.nombre_empresa}</td></tr>
      <tr><td style="padding:.5rem 0;color:#888">Contacto</td><td style="padding:.5rem 0">{form.nombre_contacto}</td></tr>
      <tr><td style="padding:.5rem 0;color:#888">Email</td><td style="padding:.5rem 0"><a href="mailto:{form.email}" style="color:#c4842a">{form.email}</a></td></tr>
      <tr><td style="padding:.5rem 0;color:#888">Teléfono</td><td style="padding:.5rem 0">{form.telefono or '—'}</td></tr>
      <tr><td style="padding:.5rem 0;color:#888">Tipo</td><td style="padding:.5rem 0"><span style="background:#e8f4e8;color:#1b3a0e;padding:.2rem .6rem;border-radius:4px;font-size:.8rem">{form.tipo_socio.value}</span></td></tr>
      <tr><td style="padding:.5rem 0;color:#888">Zona</td><td style="padding:.5rem 0">{form.zona}</td></tr>
      <tr><td style="padding:.5rem 0;color:#888">Web</td><td style="padding:.5rem 0">{f'<a href="{form.web}" style="color:#c4842a">{form.web}</a>' if form.web else '—'}</td></tr>
    </table>
    <div style="margin-top:1.5rem;padding:1rem;background:#f9f9f9;border-left:3px solid #c4842a;border-radius:0 4px 4px 0">
      <p style="color:#888;font-size:.8rem;margin:0 0 .5rem">Descripción:</p>
      <p style="margin:0;line-height:1.7;color:#333">{form.descripcion.replace(chr(10), '<br>')}</p>
    </div>
    <p style="margin-top:1.5rem;font-size:.75rem;color:#aaa">IP: {ip}</p>
  </div>
</div>
</body></html>"""

    try:
        send_email(
            subject=f"[Braña] Socio — {form.tipo_socio.value} — {form.nombre_empresa}",
            body_html=body_html,
            body_text=body_text,
            reply_to=form.email
        )
        send_autorespuesta(form.email, form.nombre_contacto, f"solicitud de socio ({form.tipo_socio.value})")
        return {"ok": True, "message": "Solicitud enviada correctamente"}
    except Exception as e:
        log.error(f"Error enviando solicitud socio: {e}")
        raise HTTPException(500, "Error al enviar la solicitud. Inténtalo de nuevo.")


if __name__ == "__main__":
    uvicorn.run("main:app", host="127.0.0.1", port=8001, reload=False)
