#!/bin/bash
# ============================================================
# BRAÑA — Instalación de la API de formularios
# Uso: sudo bash install-api.sh
# ============================================================
set -e

API_DIR="/var/www/braña-api"
WEB_DIR="/var/www/braña"

echo "=================================================="
echo "  BRAÑA — Instalando API de formularios"
echo "=================================================="

# 1. Crear directorio API
echo ""
echo "▶ 1/5 Preparando directorio..."
mkdir -p "$API_DIR"
cp api/main.py         "$API_DIR/main.py"
cp api/requirements.txt "$API_DIR/requirements.txt"
chown -R www-data:www-data "$API_DIR"

# 2. Crear entorno virtual e instalar dependencias
echo ""
echo "▶ 2/5 Instalando dependencias Python..."
apt-get install -y python3-venv python3-pip -qq
python3 -m venv "$API_DIR/venv"
"$API_DIR/venv/bin/pip" install --quiet --upgrade pip
"$API_DIR/venv/bin/pip" install --quiet -r "$API_DIR/requirements.txt"
echo "   ✓ Dependencias instaladas"

# 3. Copiar páginas HTML
echo ""
echo "▶ 3/5 Copiando páginas web..."
cp contacto.html "$WEB_DIR/contacto.html"
cp socios.html   "$WEB_DIR/socios.html"
chown www-data:www-data "$WEB_DIR/contacto.html" "$WEB_DIR/socios.html"
echo "   ✓ contacto.html y socios.html copiados"

# 4. Instalar servicio systemd
echo ""
echo "▶ 4/5 Configurando servicio systemd..."
cp braña-api.service /etc/systemd/system/braña-api.service
systemctl daemon-reload
systemctl enable braña-api
systemctl start  braña-api
sleep 2
if systemctl is-active --quiet braña-api; then
    echo "   ✓ Servicio braña-api activo"
else
    echo "   ✗ El servicio no arrancó. Revisa: journalctl -u braña-api -n 30"
fi

# 5. Añadir proxy en Nginx (si no existe ya)
echo ""
echo "▶ 5/5 Configurando proxy Nginx → API..."

NGINX_CONF="/etc/nginx/sites-available/braña"

if grep -q "location /api/" "$NGINX_CONF" 2>/dev/null; then
    echo "   Proxy /api/ ya existe en Nginx, no se modifica"
else
    # Insertar bloque proxy antes del último } del server block principal
    sed -i '/error_page 404/i\
\
    # API de formularios\
    location /api/ {\
        proxy_pass         http://127.0.0.1:8001;\
        proxy_http_version 1.1;\
        proxy_set_header   Host $host;\
        proxy_set_header   X-Real-IP $remote_addr;\
        proxy_set_header   X-Forwarded-For $proxy_add_x_forwarded_for;\
        proxy_read_timeout 30;\
        proxy_connect_timeout 10;\
    }\
' "$NGINX_CONF"
    nginx -t && systemctl reload nginx
    echo "   ✓ Proxy /api/ añadido a Nginx"
fi

echo ""
echo "=================================================="
echo "  ✓ INSTALACIÓN COMPLETADA"
echo ""
echo "  Páginas:"
echo "    https://braña.com/contacto.html"
echo "    https://braña.com/socios.html"
echo ""
echo "  API:"
echo "    https://braña.com/api/contacto  (POST)"
echo "    https://braña.com/api/socios    (POST)"
echo "    https://braña.com/api/health    (GET)"
echo ""
echo "  ⚠️  IMPORTANTE: Edita la contraseña SMTP en:"
echo "    $API_DIR/main.py  → SMTP_PASSWORD"
echo "  Luego: sudo systemctl restart braña-api"
echo "=================================================="
