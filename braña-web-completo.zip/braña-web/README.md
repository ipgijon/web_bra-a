# BRAÑA — Web Corporativa
## Paquete de despliegue completo

---

## Estructura de archivos

```
braña-web/
├── index.html              ← Página principal
├── privacidad.html         ← (pendiente de redactar)
├── terminos.html           ← (pendiente de redactar)
├── cookies.html            ← (pendiente de redactar)
├── robots.txt              ← SEO / rastreadores
├── sitemap.xml             ← Mapa del sitio
├── site.webmanifest        ← PWA manifest
├── braña.nginx             ← Config Nginx completa (HTTPS)
├── deploy.sh               ← Script de despliegue automático
├── README.md               ← Este archivo
├── css/
│   └── main.css            ← Estilos separados
├── js/
│   └── main.js             ← JavaScript (i18n, scroll, cookies)
└── img/
    ├── logo.svg            ← Logo principal (fondo claro)
    ├── logo-white.svg      ← Logo blanco (fondo oscuro)
    ← logo-mark.svg         ← Icono solo (cuadrado)
    ├── favicon.svg         ← Favicon vectorial
    ├── favicon.ico         ← Favicon multi-tamaño (16/32/48px)
    ├── apple-touch-icon.png← Icono iOS (180x180)
    └── og-image.jpg        ← Imagen Open Graph (1200x630)
```

---

## Despliegue rápido en Ubuntu

### Opción A — Script automático (recomendado)

```bash
# 1. Subir archivos al servidor
scp -r braña-web/ usuario@tu-servidor:/tmp/braña-web/

# 2. Conectarse al servidor
ssh usuario@tu-servidor

# 3. Ejecutar script de despliegue
cd /tmp/braña-web
chmod +x deploy.sh
sudo ./deploy.sh
```

### Opción B — Manual paso a paso

```bash
# 1. Actualizar sistema
sudo apt update && sudo apt upgrade -y

# 2. Instalar Nginx
sudo apt install nginx certbot python3-certbot-nginx ufw -y

# 3. Firewall
sudo ufw enable
sudo ufw allow OpenSSH
sudo ufw allow 'Nginx Full'

# 4. Crear directorio y copiar archivos
sudo mkdir -p /var/www/braña
sudo cp -r braña-web/* /var/www/braña/
sudo chown -R www-data:www-data /var/www/braña
sudo find /var/www/braña -type f -exec chmod 644 {} \;
sudo find /var/www/braña -type d -exec chmod 755 {} \;

# 5. Configurar Nginx
sudo cp braña-web/braña.nginx /etc/nginx/sites-available/braña
sudo ln -s /etc/nginx/sites-available/braña /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t
sudo systemctl reload nginx

# 6. SSL con Let's Encrypt
sudo certbot --nginx -d braña.com -d www.braña.com
# (certbot actualizará la config nginx automáticamente)

# 7. Verificar renovación automática
sudo certbot renew --dry-run
```

---

## Configuración DNS

En tu proveedor de dominio (donde registraste braña.com / braña.es), añade:

| Tipo | Nombre | Valor                  | TTL  |
|------|--------|------------------------|------|
| A    | @      | IP_DE_TU_SERVIDOR      | 3600 |
| A    | www    | IP_DE_TU_SERVIDOR      | 3600 |
| CNAME| braña.es | braña.com            | 3600 |

**Nota:** Los dominios con ñ (IDN) se registran también en Punycode:
- `braña.com` → `xn--braa-roa.com`
- `braña.es`  → `xn--braa-roa.es`

Algunos servidores y CDNs requieren el formato Punycode.

---

## Imágenes

La web usa imágenes de **Unsplash** (licencia libre para uso comercial).
Para producción se recomienda:

1. Descargar las imágenes y alojarlas localmente:
```bash
# Ejemplo de descarga (ajustar URLs del index.html)
wget -O img/hero.jpg "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=1800&q=85"
wget -O img/intro.jpg "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=1000&q=85"
# etc.
```

2. Convertir a formato WebP para mayor velocidad:
```bash
sudo apt install webp
for f in img/*.jpg img/*.png; do cwebp -q 85 "$f" -o "${f%.*}.webp"; done
```

3. Actualizar las rutas en `index.html` para usar las imágenes locales.

---

## Páginas legales pendientes

Crear los siguientes archivos (pueden ser páginas simples con el mismo estilo):
- `privacidad.html` — Política de privacidad (RGPD)
- `terminos.html`   — Términos y condiciones
- `cookies.html`    — Política de cookies

---

## Formulario de contacto

En `js/main.js`, la función `initContactForm()` gestiona el envío.
Para activarlo, elige uno de estos servicios gratuitos y actualiza el `action` del form:

- **Formspree**: https://formspree.io → `action="https://formspree.io/f/TU_ID"`
- **Netlify Forms**: añadir atributo `netlify` al form
- **Envío propio**: configurar PHP/Node en el servidor

---

## SEO y rendimiento

- ✅ Meta tags Open Graph y Twitter Card
- ✅ Schema.org JSON-LD
- ✅ Hreflang para 4 idiomas
- ✅ robots.txt y sitemap.xml
- ✅ Lazy loading de imágenes
- ✅ Gzip en Nginx
- ✅ Cache headers para assets estáticos
- ✅ HTTP/2
- ✅ HSTS
- ✅ SSL/TLS automático con Let's Encrypt

---

## Mantenimiento

```bash
# Ver logs en tiempo real
sudo tail -f /var/log/nginx/braña_access.log
sudo tail -f /var/log/nginx/braña_error.log

# Recargar Nginx tras cambios
sudo nginx -t && sudo systemctl reload nginx

# Renovar SSL manualmente
sudo certbot renew

# Estado del servidor
sudo systemctl status nginx
```

---

*Braña Alojamientos de Naturaleza · braña.com · braña.es*
