#!/bin/bash
# ============================================================
# BRAÑA — Script de despliegue en Ubuntu
# Uso: chmod +x deploy.sh && sudo ./deploy.sh
# ============================================================

set -e  # salir si hay error

echo "=================================================="
echo "  BRAÑA — Deploy en Ubuntu"
echo "=================================================="

# ── VARIABLES ── (ajusta según tu servidor)
DOMAIN="braña.com"
DOMAIN_ASCII="xn--braa-roa.com"   # Punycode para braña.com
WEB_ROOT="/var/www/braña"
NGINX_CONF="/etc/nginx/sites-available/braña"
NGINX_ENABLED="/etc/nginx/sites-enabled/braña"
DEPLOY_USER="www-data"

# ── 1. ACTUALIZAR SISTEMA ──
echo ""
echo "▶ 1/7 Actualizando sistema..."
apt-get update -qq
apt-get upgrade -y -qq

# ── 2. INSTALAR DEPENDENCIAS ──
echo ""
echo "▶ 2/7 Instalando Nginx y Certbot..."
apt-get install -y nginx certbot python3-certbot-nginx ufw -qq

# ── 3. FIREWALL ──
echo ""
echo "▶ 3/7 Configurando UFW (firewall)..."
ufw --force enable
ufw allow OpenSSH
ufw allow 'Nginx Full'
ufw status

# ── 4. CREAR DIRECTORIO WEB ──
echo ""
echo "▶ 4/7 Creando directorio web..."
mkdir -p "$WEB_ROOT"
chown -R "$DEPLOY_USER:$DEPLOY_USER" "$WEB_ROOT"
chmod -R 755 "$WEB_ROOT"

# ── 5. COPIAR ARCHIVOS ──
echo ""
echo "▶ 5/7 Copiando archivos web..."
# Copiar todo el contenido del directorio actual
cp -r ./* "$WEB_ROOT/"
# Aseguramos permisos correctos
chown -R "$DEPLOY_USER:$DEPLOY_USER" "$WEB_ROOT"
find "$WEB_ROOT" -type f -exec chmod 644 {} \;
find "$WEB_ROOT" -type d -exec chmod 755 {} \;
echo "   Archivos copiados a $WEB_ROOT"

# ── 6. CONFIGURAR NGINX ──
echo ""
echo "▶ 6/7 Configurando Nginx..."

# Config temporal HTTP (para que certbot pueda verificar)
cat > "$NGINX_CONF" << 'NGINXCONF'
server {
    listen 80;
    listen [::]:80;
    server_name braña.com www.braña.com xn--braa-roa.com www.xn--braa-roa.com braña.es www.braña.es;
    root /var/www/braña;
    index index.html;
    charset utf-8;

    location / {
        try_files $uri $uri/ /index.html;
    }

    location ~* \.(css|js|svg|ico|woff|woff2|ttf|eot)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    location ~* \.(jpg|jpeg|png|gif|webp)$ {
        expires 6M;
        add_header Cache-Control "public";
    }

    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_comp_level 6;
    gzip_types text/plain text/css application/json application/javascript image/svg+xml;

    location ~ /\. { deny all; }
}
NGINXCONF

# Habilitar site
if [ ! -L "$NGINX_ENABLED" ]; then
    ln -s "$NGINX_CONF" "$NGINX_ENABLED"
fi

# Desactivar default si existe
if [ -L /etc/nginx/sites-enabled/default ]; then
    rm /etc/nginx/sites-enabled/default
fi

nginx -t
systemctl reload nginx
echo "   Nginx configurado y recargado (HTTP)"

# ── 7. SSL CON LET'S ENCRYPT ──
echo ""
echo "▶ 7/7 Configurando SSL (Let's Encrypt)..."
echo ""
echo "   IMPORTANTE: Asegúrate de que los DNS de $DOMAIN"
echo "   apuntan ya a la IP de este servidor antes de continuar."
echo ""
read -p "   ¿Los DNS están configurados y propagados? (s/N): " dns_ok

if [[ "$dns_ok" =~ ^[Ss]$ ]]; then
    certbot --nginx \
        -d "$DOMAIN" -d "www.$DOMAIN" \
        -d "$DOMAIN_ASCII" -d "www.$DOMAIN_ASCII" \
        --non-interactive --agree-tos \
        --email "hola@$DOMAIN" \
        --redirect

    # Copiar config Nginx completa con HTTPS
    cp braña.nginx "$NGINX_CONF"
    nginx -t && systemctl reload nginx
    echo "   ✓ SSL configurado correctamente"

    # Auto-renovación
    systemctl enable certbot.timer
    systemctl start certbot.timer
    echo "   ✓ Renovación automática SSL activada"
else
    echo "   SSL pospuesto. Ejecuta manualmente:"
    echo "   sudo certbot --nginx -d $DOMAIN -d www.$DOMAIN"
fi

echo ""
echo "=================================================="
echo "  ✓ DESPLIEGUE COMPLETADO"
echo ""
echo "  Web disponible en: http://$DOMAIN"
if [[ "$dns_ok" =~ ^[Ss]$ ]]; then
    echo "  Web segura en:    https://$DOMAIN"
fi
echo ""
echo "  Directorio web:   $WEB_ROOT"
echo "  Log de acceso:    /var/log/nginx/braña_access.log"
echo "  Log de errores:   /var/log/nginx/braña_error.log"
echo "=================================================="
