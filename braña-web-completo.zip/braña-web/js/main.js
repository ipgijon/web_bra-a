/* ============================================================
   BRAÑA — main.js
   ============================================================ */

'use strict';

/* ── TRADUCCIONES ── */
const T = {
  es:{
    nav_z:"Destinos",nav_a:"Alojamiento",nav_e:"Experiencias",nav_s:"Socios",nav_c:"Contacto",
    h_ey:"Asturias · Galicia · Naturaleza",h_em:"Entornos únicos",scroll:"Explorar",
    h_c1:"Descubrir destinos",h_c2:"Ver experiencias",
    h_p:"Alojamientos de naturaleza en los Picos de Europa, la costa asturiana y Barreiros. Con experiencias diseñadas para vivir el entorno en profundidad.",
    i_lbl:"Nuestra filosofía",i_ttl:"Donde la <em>braña</em><br>da nombre<br>a un estilo de vida",
    i_b1:"La braña es la pradera de altura asturiana, el lugar al que suben los vaqueiros en verano buscando los mejores pastos. Nosotros buscamos lo mismo: los parajes más auténticos y singulares del norte de España.",
    i_b2:"Cada finca Braña es un alojamiento pensado para desconectar de verdad: rodeado de naturaleza, con diseño contemporáneo, y con acceso a las mejores experiencias del entorno a través de nuestra red de socios locales.",
    st1:"Comunidades",st2:"Municipios",st3:"Experiencias",
    zl:"Nuestros destinos",zt:"Picos, valles<br><em>y costa salvaje</em>",
    zb:"Operamos en el corazón de Asturias y en la costa de Lugo. Todos los entornos elegidos por su valor paisajístico excepcional y su riqueza de experiencias.",
    z1t:"Asturias · Interior · Picos de Europa",z1n:"Cangas de Onís<br>& Covadonga",z1d:"La puerta a los Picos de Europa. Lagos de Covadonga, el Cares, Corao y los valles del Sella y Güeña.",
    z2t:"Asturias · Valle",z2n:"Cabrales &<br>Peñamellera",z2d:"Valles profundos, queso Cabrales, ríos cristalinos y paredes de escalada de primer nivel mundial.",
    z3t:"Asturias · Rural",z3n:"Benia de Onís<br>& Parres",z3d:"El Asturias más tranquilo y auténtico, con praderas verdes y vistas a la Cordillera Cantábrica.",
    z4t:"Asturias · Costa",z4n:"Llanes &<br>Ribadesella",z4d:"Acantilados y playas salvajes. Surf atlántico, descenso del Sella y la mejor sidra de Asturias.",
    z5t:"Galicia · Costa Lugo",z5n:"Barreiros",z5d:"La costa más salvaje de Lugo. Playas vírgenes, marisco de primera y el Atlántico en estado puro.",
    al:"El alojamiento",at:"Diseño contemporáneo<br><em>en plena naturaleza</em>",
    ab:"Cada finca Braña cuenta con una casa móvil de diseño nórdico y una piscina de acero de diseño premium. Sin obra, sin permisos, máximo confort desde el primer día.",
    a1b:"Casa móvil",a1n:"Oslo — 2 dormitorios",
    a1d:"Casa móvil de diseño escandinavo con salón, 2 dormitorios y acabados de lujo. Puertas francesas que se abren al paisaje, cocina totalmente equipada, baño de lujo, aire acondicionado y calefacción central.",
    a2b:"Piscina privada",a2n:"ILÚ PRO 230",
    a2d:"Piscina elevada de acero galvanizado con ventana de metacrilato en el lateral. Entregada montada en una sola pieza, sin obra ni licencias. LED, escalera interior y exterior. Opción TOP con calentador e hidromasaje.",
    el:"Experiencias",et:"Más allá del<br><em>alojamiento</em>",
    eb:"Concertadas con los mejores operadores locales de cada zona. Del Sella a los Picos, del mar al valle.",
    e1t:"Ribadesella · Río Sella",e1n:"Descenso del Sella",e1d:"El descenso en canoa más famoso de España. 20 km desde Arriondas hasta Ribadesella entre bosques y montaña.",
    e2t:"Picos de Europa",e2n:"Ruta del Cares",e2d:"12 km entre paredes verticales de 1.000 metros sobre el desfiladero más impresionante del norte.",
    e3t:"Cabrales · Peñamellera",e3n:"Escalada en los Picos",e3d:"Paredes de caliza de nivel mundial con guías titulados para todos los niveles.",
    e4t:"Cangas de Onís",e4n:"Covadonga<br>& los Lagos",e4d:"Los Lagos Enol y Ercina a más de 1.100 m. Historia viva y paisaje de otro mundo.",
    e5t:"Llanes · Ribadesella · Costa",e5n:"Surf en la costa asturiana",e5d:"Olas atlánticas en playas vírgenes. Clases con escuelas locales certificadas, tablas y material incluido.",
    e6t:"Valles asturianos",e6n:"Rutas a caballo",e6d:"Travesías por praderas y bosques atlánticos con caballos autóctonos y guías especializados.",
    e7t:"Asturias · Toda la región",e7n:"Sidrerías &<br>gastronomía",e7d:"Queso Cabrales, sidra natural, fabada y marisco. Los mejores restaurantes y llagares locales.",
    e8t:"Barreiros · Costa Lugo",e8n:"Barco & marisco<br>en Barreiros",e8d:"Salidas en barco de pesca, marisco de la ría y excursiones por la costa salvaje de Lugo.",
    sl:"Red de socios",st_t:"Colaboramos con<br><em>lo mejor de cada zona</em>",
    sb:"Acuerdos estables con operadores turísticos locales de primer nivel. Experiencias auténticas directamente desde la finca, sin gestiones intermedias.",
    sc:"¿Eres socio potencial?",
    s1c:"Gastronomía",s1n:"Sidrerías, restaurantes & llagares",s1d:"Lo mejor de la cocina asturiana: queso Cabrales, marisco, sidra natural, fabada y chosco.",
    s2c:"Aventura & montaña",s2n:"Guías, escuelas & federaciones",s2d:"Escalada, senderismo y canoa con los mejores operadores de los Picos de Europa y el Sella.",
    s3c:"Náutica & costa",s3n:"Cofradías, surf & barcos",s3d:"Escuelas de surf en Llanes y Ribadesella, y patrones en Barreiros para excursiones marítimas.",
    s4c:"Logística & transfer",s4n:"Transfer & alquiler de vehículos",s4d:"Recogida en aeropuertos de Asturias y Santiago, y vehículos locales para explorar el entorno.",
    cl:"El proyecto",ct:"Estamos construyendo<br><em>algo especial</em><br>en Asturias",
    cb:"Braña está seleccionando sus primeras fincas en Cangas de Onís, Cabrales, Llanes y Barreiros. Si quieres saber más sobre el proyecto, colaborar como socio local o explorar opciones de inversión, escríbenos.",
    cb1:"Contactar",cb2:"Seguir el proyecto",
    fd:"Alojamientos de naturaleza en Asturias y Galicia. Picos de Europa, costa atlántica y valles únicos.",
    fc1:"Destinos",fc2:"Proyecto",fc3:"Legal",fa:"Sobre Braña",fst:"Alojamiento",fp:"Socios",fco:"Contacto",
    fpr:"Privacidad",ft_:"Términos",fck:"Cookies",fl:"Donde la naturaleza da la bienvenida",
    ck_txt:'Usamos cookies para mejorar tu experiencia. <a href="/privacidad.html">Saber más</a>.',
    ck_ok:"Aceptar",ck_no:"Rechazar"
  },
  en:{
    nav_z:"Destinations",nav_a:"Accommodation",nav_e:"Experiences",nav_s:"Partners",nav_c:"Contact",
    h_ey:"Asturias · Galicia · Nature",h_em:"Unique settings",scroll:"Explore",
    h_c1:"Discover destinations",h_c2:"See experiences",
    h_p:"Nature lodgings in the Picos de Europa, the Asturian coast and Barreiros. With experiences designed to immerse you in the landscape.",
    i_lbl:"Our philosophy",i_ttl:"Where <em>braña</em><br>names<br>a way of life",
    i_b1:"The braña is the Asturian highland meadow where cattle herders head in summer for the finest pastures. We seek the same: the most authentic landscapes in northern Spain.",
    i_b2:"Each Braña property is designed for true disconnection: surrounded by nature, contemporary design, and access to the best local experiences through our partner network.",
    st1:"Regions",st2:"Municipalities",st3:"Experiences",
    zl:"Our destinations",zt:"Peaks, valleys<br><em>and wild coast</em>",
    zb:"We operate in the heart of Asturias and on the Lugo coast. Every location chosen for its exceptional scenic value.",
    z1t:"Asturias · Inland · Picos de Europa",z1n:"Cangas de Onís<br>& Covadonga",z1d:"Gateway to the Picos de Europa. Covadonga lakes, the Cares gorge and the Sella valleys.",
    z2t:"Asturias · Valley",z2n:"Cabrales &<br>Peñamellera",z2d:"Deep valleys, Cabrales cheese, crystal rivers and world-class limestone climbing.",
    z3t:"Asturias · Rural",z3n:"Benia de Onís<br>& Parres",z3d:"The quietest and most authentic Asturias, with green meadows and views of the Cantabrian range.",
    z4t:"Asturias · Coast",z4n:"Llanes &<br>Ribadesella",z4d:"Cliffside coast and wild beaches. Atlantic surf, the Sella descent and the best Asturian cider.",
    z5t:"Galicia · Lugo Coast",z5n:"Barreiros",z5d:"The wildest coast of Lugo. Virgin beaches, premium seafood and the Atlantic at its most raw.",
    al:"Accommodation",at:"Contemporary design<br><em>in pure nature</em>",
    ab:"Every Braña property features a Nordic-design mobile home and a premium steel pool. No construction, no permits, maximum comfort from day one.",
    a1b:"Mobile home",a1n:"Oslo — 2 bedrooms",
    a1d:"Scandinavian-design mobile home with living room, 2 bedrooms and luxury finishes. French doors to the landscape, fully fitted kitchen, luxury bathroom, A/C and central heating.",
    a2b:"Private pool",a2n:"ILÚ PRO 230",
    a2d:"Elevated galvanised steel pool with acrylic viewing window. Delivered assembled in one piece — no works, no permits. LED lighting, interior and exterior steps. TOP model with heater and hydromassage.",
    el:"Experiences",et:"Beyond<br><em>accommodation</em>",eb:"Arranged with the best local operators. From the Sella to the Picos, from the sea to the valley.",
    e1t:"Ribadesella · River Sella",e1n:"Sella descent",e1d:"Spain's most famous canoe descent. 20 km from Arriondas to Ribadesella.",
    e2t:"Picos de Europa",e2n:"Cares gorge trail",e2d:"12 km between 1,000 m vertical walls above the most spectacular ravine in northern Spain.",
    e3t:"Cabrales · Peñamellera",e3n:"Climbing in the Picos",e3d:"World-class limestone walls with certified mountain guides for all levels.",
    e4t:"Cangas de Onís",e4n:"Covadonga<br>& the Lakes",e4d:"Lakes Enol and Ercina above 1,100 m. Living history and otherworldly landscape.",
    e5t:"Llanes · Ribadesella · Coast",e5n:"Surfing the Asturian coast",e5d:"Atlantic waves on wild beaches. Lessons with certified local schools, equipment included.",
    e6t:"Asturian valleys",e6n:"Horse riding",e6d:"Rides through Atlantic meadows and forests with native horses and specialist guides.",
    e7t:"Asturias · All regions",e7n:"Cider houses<br>& gastronomy",e7d:"Cabrales cheese, natural cider, fabada and seafood. The best local restaurants, reserved for you.",
    e8t:"Barreiros · Lugo Coast",e8n:"Boat & seafood<br>in Barreiros",e8d:"Fishing boat trips, fresh seafood and coastal excursions with local skippers.",
    sl:"Partner network",st_t:"We work with<br><em>the best of each place</em>",
    sb:"Stable agreements with top-tier local tourism operators. Authentic experiences directly from the property.",sc:"Are you a potential partner?",
    s1c:"Gastronomy",s1n:"Cider houses, restaurants & mills",s1d:"Finest Asturian cuisine: Cabrales cheese, seafood, natural cider and fabada.",
    s2c:"Adventure & mountain",s2n:"Guides, schools & federations",s2d:"Climbing, hiking and canoeing with the leading operators in the Picos de Europa.",
    s3c:"Nautical & coast",s3n:"Guilds, surf & boats",s3d:"Surf schools in Llanes and Ribadesella, local skippers in Barreiros.",
    s4c:"Logistics & transfer",s4n:"Transfer & vehicle hire",s4d:"Pick-up at Asturias and Santiago airports, local vehicles to explore.",
    cl:"The project",ct:"We are building<br><em>something special</em><br>in Asturias",
    cb:"Braña is selecting its first properties in Cangas de Onís, Cabrales, Llanes and Barreiros. To learn more, partner or invest, write to us.",
    cb1:"Contact us",cb2:"Follow the project",
    fd:"Nature lodgings in Asturias and Galicia. Picos de Europa, Atlantic coast and unique valleys.",
    fc1:"Destinations",fc2:"Project",fc3:"Legal",fa:"About Braña",fst:"Accommodation",fp:"Partners",fco:"Contact",
    fpr:"Privacy",ft_:"Terms",fck:"Cookies",fl:"Where nature welcomes you",
    ck_txt:'We use cookies to improve your experience. <a href="/privacy.html">Learn more</a>.',
    ck_ok:"Accept",ck_no:"Decline"
  },
  de:{
    nav_z:"Ziele",nav_a:"Unterkunft",nav_e:"Erlebnisse",nav_s:"Partner",nav_c:"Kontakt",
    h_ey:"Asturien · Galicien · Natur",h_em:"Einzigartige Orte",scroll:"Erkunden",
    h_c1:"Ziele entdecken",h_c2:"Erlebnisse ansehen",
    h_p:"Naturunterkünfte in den Picos de Europa, an der asturischen Küste und in Barreiros.",
    i_lbl:"Unsere Philosophie",i_ttl:"Wo die <em>Braña</em><br>einem Lebensstil<br>ihren Namen gibt",
    i_b1:"Die Braña ist die asturische Hochlandweide. Wir suchen die authentischsten Orte im Norden Spaniens.",
    i_b2:"Jedes Braña-Anwesen ist für echtes Abschalten konzipiert: Natur, zeitgemäßes Design und beste lokale Erlebnisse.",
    st1:"Regionen",st2:"Gemeinden",st3:"Erlebnisse",
    zl:"Unsere Ziele",zt:"Gipfel, Täler<br><em>und wilde Küste</em>",zb:"Im Herzen Asturiens und an der Küste von Lugo.",
    z1t:"Asturien · Inland",z1n:"Cangas de Onís<br>& Covadonga",z1d:"Das Tor zu den Picos de Europa. Covadonga-Seen und die Cares-Schlucht.",
    z2t:"Asturien · Tal",z2n:"Cabrales &<br>Peñamellera",z2d:"Cabrales-Käse, kristallklare Flüsse und weltklasse Klettern.",
    z3t:"Asturien · Ländlich",z3n:"Benia de Onís<br>& Parres",z3d:"Das ruhigste Asturien mit Blick auf das Kantabrische Gebirge.",
    z4t:"Asturien · Küste",z4n:"Llanes &<br>Ribadesella",z4d:"Klippenküste und wilde Strände. Surfen und der beste Cidre Asturiens.",
    z5t:"Galicien · Küste Lugo",z5n:"Barreiros",z5d:"Die wildeste Küste Lugos. Unberührte Strände und erstklassige Meeresfrüchte.",
    al:"Unterkunft",at:"Zeitgemäßes Design<br><em>mitten in der Natur</em>",ab:"Mobilheim und Premium-Stahlpool. Ohne Bauarbeiten, ohne Genehmigungen.",
    a1b:"Mobilheim",a1n:"Oslo — 2 Schlafzimmer",a1d:"Skandinavisch gestaltetes Mobilheim mit Wohnzimmer, 2 Schlafzimmern und Luxusausstattung.",
    a2b:"Privater Pool",a2n:"ILÚ PRO 230",a2d:"Erhöhter Stahlpool mit Acrylglasfenster. In einem Stück geliefert. TOP-Modell mit Heizung und Hydromassage.",
    el:"Erlebnisse",et:"Mehr als nur<br><em>Unterkunft</em>",eb:"Mit den besten Anbietern vor Ort vereinbart.",
    e1t:"Ribadesella · Fluss Sella",e1n:"Sella-Abstieg",e1d:"Spaniens bekanntester Kanuabstieg. 20 km durch Wälder und Berge.",
    e2t:"Picos de Europa",e2n:"Cares-Schlucht",e2d:"12 km zwischen 1.000 m hohen Wänden.",
    e3t:"Cabrales · Peñamellera",e3n:"Klettern in den Picos",e3d:"Weltklasse-Kalksteinwände für alle Niveaus.",
    e4t:"Cangas de Onís",e4n:"Covadonga<br>& die Seen",e4d:"Seen Enol und Ercina auf über 1.100 m.",
    e5t:"Küste",e5n:"Surfen an der asturischen Küste",e5d:"Atlantikwellen. Kurse mit zertifizierten Schulen.",
    e6t:"Asturische Täler",e6n:"Reiten",e6d:"Ausritte mit einheimischen Pferden und Spezialführern.",
    e7t:"Asturien",e7n:"Cidrería &<br>Gastronomie",e7d:"Cabrales-Käse, Cidre, Fabada und Meeresfrüchte.",
    e8t:"Barreiros",e8n:"Boot & Meeresfrüchte",e8d:"Fischerbootausflüge und frische Meeresfrüchte.",
    sl:"Partnernetzwerk",st_t:"Wir arbeiten mit<br><em>dem Besten vor Ort</em>",sb:"Stabile Vereinbarungen mit erstklassigen lokalen Anbietern.",sc:"Sind Sie ein potenzieller Partner?",
    s1c:"Gastronomie",s1n:"Cidrerías & Restaurants",s1d:"Beste asturische Küche.",
    s2c:"Abenteuer",s2n:"Guides & Schulen",s2d:"Klettern, Wandern und Kanufahren.",
    s3c:"Nautik",s3n:"Surf & Boote",s3d:"Surfschulen und lokale Skipper.",
    s4c:"Logistik",s4n:"Transfer & Fahrzeuge",s4d:"Flughafentransfer und lokale Fahrzeuge.",
    cl:"Das Projekt",ct:"Wir bauen<br><em>etwas Besonderes</em><br>in Asturien",cb:"Schreiben Sie uns für mehr Informationen.",
    cb1:"Kontakt",cb2:"Projekt verfolgen",
    fd:"Naturunterkünfte in Asturien und Galicien.",fc1:"Ziele",fc2:"Projekt",fc3:"Rechtliches",
    fa:"Über Braña",fst:"Unterkunft",fp:"Partner",fco:"Kontakt",fpr:"Datenschutz",ft_:"AGB",fck:"Cookies",
    fl:"Wo die Natur willkommen heißt",ck_txt:'Wir verwenden Cookies.',ck_ok:"Akzeptieren",ck_no:"Ablehnen"
  },
  fr:{
    nav_z:"Destinations",nav_a:"Hébergement",nav_e:"Expériences",nav_s:"Partenaires",nav_c:"Contact",
    h_ey:"Asturies · Galice · Nature",h_em:"Cadres uniques",scroll:"Explorer",
    h_c1:"Découvrir les destinations",h_c2:"Voir les expériences",
    h_p:"Hébergements en pleine nature dans les Picos de Europa, sur la côte des Asturies et à Barreiros.",
    i_lbl:"Notre philosophie",i_ttl:"Là où la <em>braña</em><br>donne son nom<br>à un art de vivre",
    i_b1:"La braña est la prairie d'altitude asturienne. Nous cherchons les paysages les plus authentiques du nord de l'Espagne.",
    i_b2:"Chaque propriété Braña est pensée pour une vraie déconnexion : nature, design et accès aux meilleures expériences locales.",
    st1:"Régions",st2:"Communes",st3:"Expériences",
    zl:"Nos destinations",zt:"Pics, vallées<br><em>et côte sauvage</em>",zb:"Au cœur des Asturies et sur la côte de Lugo.",
    z1t:"Asturies · Intérieur",z1n:"Cangas de Onís<br>& Covadonga",z1d:"La porte des Picos de Europa. Lacs de Covadonga et gorges du Cares.",
    z2t:"Asturies · Vallée",z2n:"Cabrales &<br>Peñamellera",z2d:"Fromage Cabrales, rivières cristallines et escalade de niveau mondial.",
    z3t:"Asturies · Rural",z3n:"Benia de Onís<br>& Parres",z3d:"Les Asturies les plus calmes avec vues sur la Cordillère Cantabrique.",
    z4t:"Asturies · Côte",z4n:"Llanes &<br>Ribadesella",z4d:"Côte de falaises et plages sauvages. Surf et meilleur cidre des Asturies.",
    z5t:"Galice · Côte Lugo",z5n:"Barreiros",z5d:"La côte la plus sauvage de Lugo. Plages vierges et fruits de mer d'exception.",
    al:"Hébergement",at:"Design contemporain<br><em>au cœur de la nature</em>",ab:"Maison mobile nordique et piscine en acier premium. Sans travaux, sans permis.",
    a1b:"Maison mobile",a1n:"Oslo — 2 chambres",a1d:"Maison mobile scandinave avec séjour, 2 chambres et finitions luxueuses.",
    a2b:"Piscine privée",a2n:"ILÚ PRO 230",a2d:"Piscine surélevée en acier galvanisé avec hublot acrylique. Livrée montée, sans travaux ni permis.",
    el:"Expériences",et:"Au-delà de<br><em>l'hébergement</em>",eb:"Organisées avec les meilleurs opérateurs locaux.",
    e1t:"Ribadesella · Rivière Sella",e1n:"Descente du Sella",e1d:"La descente en canoë la plus célèbre d'Espagne. 20 km entre forêts et montagnes.",
    e2t:"Picos de Europa",e2n:"Gorges du Cares",e2d:"12 km entre des parois de 1 000 m.",
    e3t:"Cabrales · Peñamellera",e3n:"Escalade dans les Picos",e3d:"Parois calcaires de niveau mondial.",
    e4t:"Cangas de Onís",e4n:"Covadonga<br>& les Lacs",e4d:"Lacs Enol et Ercina à plus de 1 100 m.",
    e5t:"Côte",e5n:"Surf sur la côte des Asturies",e5d:"Vagues atlantiques. Cours avec écoles certifiées.",
    e6t:"Vallées asturiennes",e6n:"Randonnée à cheval",e6d:"Traversées avec chevaux locaux et guides spécialisés.",
    e7t:"Asturies",e7n:"Cidreries &<br>gastronomie",e7d:"Fromage Cabrales, cidre naturel, fabada et fruits de mer.",
    e8t:"Barreiros",e8n:"Bateau & fruits de mer",e8d:"Sorties en bateau et fruits de mer frais.",
    sl:"Réseau de partenaires",st_t:"Nous collaborons avec<br><em>le meilleur de chaque lieu</em>",sb:"Accords stables avec des opérateurs touristiques locaux de premier rang.",sc:"Vous êtes partenaire potentiel ?",
    s1c:"Gastronomie",s1n:"Cidreries & restaurants",s1d:"La meilleure cuisine asturienne.",
    s2c:"Aventure",s2n:"Guides & écoles",s2d:"Escalade, randonnée et canoë.",
    s3c:"Nautisme",s3n:"Surf & bateaux",s3d:"Écoles de surf et patrons locaux.",
    s4c:"Logistique",s4n:"Transfert & véhicules",s4d:"Transferts aéroport et véhicules locaux.",
    cl:"Le projet",ct:"Nous construisons<br><em>quelque chose de spécial</em><br>en Asturies",cb:"Écrivez-nous pour en savoir plus.",
    cb1:"Nous contacter",cb2:"Suivre le projet",
    fd:"Hébergements en pleine nature en Asturies et Galice.",fc1:"Destinations",fc2:"Projet",fc3:"Légal",
    fa:"À propos de Braña",fst:"Hébergement",fp:"Partenaires",fco:"Contact",fpr:"Confidentialité",ft_:"Conditions",fck:"Cookies",
    fl:"Là où la nature vous accueille",ck_txt:'Nous utilisons des cookies.',ck_ok:"Accepter",ck_no:"Refuser"
  }
};

/* ── CAMBIO DE IDIOMA ── */
function setLang(l) {
  const t = T[l];
  if (!t) return;
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const k = el.getAttribute('data-i18n');
    if (t[k] !== undefined) el.innerHTML = t[k];
  });
  document.documentElement.lang = l;
  document.querySelectorAll('.lang-sw button').forEach(b => b.classList.remove('on'));
  const btn = document.getElementById('b-' + l);
  if (btn) btn.classList.add('on');
  localStorage.setItem('brana_lang', l);
  // update cookie text
  const ckp = document.querySelector('#cookie-banner p');
  if (ckp && t.ck_txt) ckp.innerHTML = t.ck_txt;
  const ckOk = document.querySelector('.btn-accept');
  if (ckOk && t.ck_ok) ckOk.textContent = t.ck_ok;
  const ckNo = document.querySelector('.btn-decline');
  if (ckNo && t.ck_no) ckNo.textContent = t.ck_no;
}
window.setLang = setLang;

/* ── SCROLL PROGRESS BAR ── */
function updateProgress() {
  const el = document.getElementById('scroll-progress');
  if (!el) return;
  const h = document.documentElement.scrollHeight - window.innerHeight;
  const pct = h > 0 ? (window.scrollY / h) * 100 : 0;
  el.style.width = pct + '%';
}

/* ── NAV SCROLL ── */
function onScroll() {
  const nav = document.getElementById('nav');
  if (nav) nav.classList.toggle('scrolled', window.scrollY > 60);
  updateProgress();
}

/* ── REVEAL ON SCROLL ── */
function initReveal() {
  const obs = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.classList.add('on');
        obs.unobserve(e.target);
      }
    });
  }, { threshold: 0.08 });
  document.querySelectorAll('.rv').forEach(el => obs.observe(el));
}

/* ── LAZY LOAD IMAGES ── */
function initLazyLoad() {
  if ('loading' in HTMLImageElement.prototype) {
    document.querySelectorAll('img[data-src]').forEach(img => {
      img.src = img.dataset.src;
    });
  } else {
    const obs = new IntersectionObserver(entries => {
      entries.forEach(e => {
        if (e.isIntersecting) {
          const img = e.target;
          img.src = img.dataset.src;
          obs.unobserve(img);
        }
      });
    });
    document.querySelectorAll('img[data-src]').forEach(img => obs.observe(img));
  }
}

/* ── COOKIE BANNER ── */
function initCookies() {
  if (localStorage.getItem('brana_cookies')) return;
  const banner = document.getElementById('cookie-banner');
  if (!banner) return;
  setTimeout(() => banner.classList.add('show'), 1500);
  document.querySelector('.btn-accept')?.addEventListener('click', () => {
    localStorage.setItem('brana_cookies', 'accepted');
    banner.classList.remove('show');
  });
  document.querySelector('.btn-decline')?.addEventListener('click', () => {
    localStorage.setItem('brana_cookies', 'declined');
    banner.classList.remove('show');
  });
}

/* ── SMOOTH ANCHOR SCROLL ── */
function initSmoothScroll() {
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
      const target = document.querySelector(a.getAttribute('href'));
      if (!target) return;
      e.preventDefault();
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  });
}

/* ── CONTACT FORM ── */
function initContactForm() {
  const form = document.getElementById('contact-form');
  if (!form) return;
  form.addEventListener('submit', async e => {
    e.preventDefault();
    const btn = form.querySelector('button[type=submit]');
    const orig = btn.textContent;
    btn.textContent = '...';
    btn.disabled = true;
    // Replace with your form endpoint (e.g. Formspree, Netlify Forms, etc.)
    try {
      const res = await fetch(form.action, {
        method:'POST', body: new FormData(form),
        headers:{'Accept':'application/json'}
      });
      if (res.ok) {
        form.innerHTML = '<p style="color:var(--amber-light);font-size:.9rem;text-align:center;padding:2rem 0">✓ Mensaje enviado. Te contactaremos pronto.</p>';
      } else { throw new Error(); }
    } catch {
      btn.textContent = orig;
      btn.disabled = false;
      alert('Error al enviar. Inténtalo de nuevo o escribe a hola@braña.com');
    }
  });
}

/* ── INIT ── */
document.addEventListener('DOMContentLoaded', () => {
  // Detect saved language or browser language
  const saved = localStorage.getItem('brana_lang');
  const browserLang = (navigator.language || 'es').substring(0, 2);
  const lang = saved || (['es','en','de','fr'].includes(browserLang) ? browserLang : 'es');
  setLang(lang);

  window.addEventListener('scroll', onScroll, { passive: true });
  initReveal();
  initLazyLoad();
  initCookies();
  initSmoothScroll();
  initContactForm();
  onScroll(); // initial call
});
